package com.CourierManagement.AdminService.Config;


import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.security.Key;

@Component
public class JwtUtil {

 @Value("${app.jwt.secret}")
 private String secret;

 public String extractEmail(String token) {
     return parseClaims(token).getSubject();
 }

 public String extractRole(String token) {
     return (String) parseClaims(token).get("role");
 }

 public boolean validateToken(String token) {
     try {
         parseClaims(token);
         return true;
     } catch (JwtException | IllegalArgumentException e) {
         return false;
     }
 }

 private Claims parseClaims(String token) {
     return Jwts.parserBuilder()
             .setSigningKey(getSigningKey())
             .build()
             .parseClaimsJws(token)
             .getBody();
 }

 private Key getSigningKey() {
     return Keys.hmacShaKeyFor(secret.getBytes());
 }
}